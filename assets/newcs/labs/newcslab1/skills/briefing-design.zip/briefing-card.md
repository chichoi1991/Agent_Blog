# 브리핑 카드 — 템플릿 (텍스트 + Adaptive Card)
# `{{ }}` 자리를 요약/키워드 결과로 채웁니다. 구조·순서·이모지는 그대로 둡니다.
# Teams에 일반 메시지로 보낼 때는 아래 "텍스트 템플릿"을, 리치 카드로 보낼 때는
# "Adaptive Card 템플릿"(JSON 코드블록)을 사용합니다.
# (스킬 zip 호환을 위해 Adaptive Card는 별도 .json 파일이 아니라 이 .md 안에 코드블록으로 둡니다.)

## 텍스트 템플릿 (기본)

📄 **보고자료 브리핑** — {{문서 제목}} ({{작성일/버전}})

**한 줄 요약**
{{한 줄 요약}}

**핵심 내용**
- {{핵심 1}}
- {{핵심 2}}
- {{핵심 3}}

🏷️ **핵심 키워드**: {{k1}} · {{k2}} · {{k3}} · {{k4}}

⚠️ **리스크/주의**: {{r1}} · {{r2}}   (없으면: 없음)

🔗 원문: {{문서 링크}}

## Adaptive Card 템플릿 (선택 — 리치 카드)

색은 `design.md` 매핑대로 의미 색 enum(`Accent`/`Attention`)과 `emphasis` 컨테이너만 씁니다.
아래 JSON의 `{{ }}` 자리만 값으로 치환합니다.

```json
{
  "type": "AdaptiveCard",
  "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
  "version": "1.4",
  "body": [
    {
      "type": "Container",
      "style": "emphasis",
      "bleed": true,
      "items": [
        { "type": "TextBlock", "text": "📄 보고자료 브리핑", "weight": "Bolder", "size": "Small", "color": "Accent", "spacing": "None" },
        { "type": "TextBlock", "text": "{{문서 제목}}", "weight": "Bolder", "size": "Medium", "wrap": true, "spacing": "None" },
        { "type": "TextBlock", "text": "{{작성일/버전}}", "isSubtle": true, "size": "Small", "spacing": "None", "wrap": true }
      ]
    },
    { "type": "TextBlock", "text": "한 줄 요약", "weight": "Bolder", "color": "Accent", "spacing": "Medium", "wrap": true },
    { "type": "TextBlock", "text": "{{한 줄 요약}}", "wrap": true },
    { "type": "TextBlock", "text": "핵심 내용", "weight": "Bolder", "color": "Accent", "spacing": "Medium", "wrap": true },
    { "type": "TextBlock", "text": "- {{핵심 1}}\n- {{핵심 2}}\n- {{핵심 3}}", "wrap": true },
    { "type": "TextBlock", "text": "🏷️ 핵심 키워드", "weight": "Bolder", "color": "Accent", "spacing": "Medium", "wrap": true },
    { "type": "TextBlock", "text": "{{k1}} · {{k2}} · {{k3}} · {{k4}}", "wrap": true, "spacing": "None" },
    { "type": "TextBlock", "text": "⚠️ 리스크/주의", "weight": "Bolder", "color": "Attention", "spacing": "Medium", "wrap": true },
    { "type": "TextBlock", "text": "{{r1}} · {{r2}}", "color": "Attention", "wrap": true, "spacing": "None" }
  ],
  "actions": [
    { "type": "Action.OpenUrl", "title": "🔗 원문 열기", "url": "{{문서 링크}}" }
  ]
}
```

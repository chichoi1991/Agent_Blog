---
name: brand-comms-v2
description: 분석 결과로 메일·HTML 보고서를 만들 때 사용. 회사 디자인(아이보리 배경·마젠타 포인트)을 적용하고, 메일은 받는 사람 확인 후 보내는 규칙. "메일·보고서·리포트·발송·공유" 요청 시.
---

# 메일·보고서 만들기 (회사 디자인)

## 언제 쓰나
분석 결과를 메일이나 보고서로 전달할 때.

## 디자인 (고정 — 이 값을 그대로 사용)

색은 추측하지 말고 아래 값을 그대로 씁니다. (전체 안내·예시는 `design-set.md`)

| 역할 | HEX |
|---|---|
| 배경(아이보리) | `#FBF6EC` |
| 포인트(마젠타) | `#C2185B` |
| 포인트 옅게(강조 배경) | `#FBE3EC` |
| 본문 글자 | `#2A2330` |
| 보조 글자 | `#7A7382` |
| 경계선 | `#ECE3D2` |

- 배경은 항상 아이보리. 제목 바·강조 숫자·표 머리·막대는 마젠타. 본문 글자는 어두운 회색(가독성).
- ❌ 파랑·초록 등 다른 강조색(증감 +/− 표시는 예외)·그라데이션 남발·색·폰트 임의 변경 금지.
- **새로 디자인하지 마세요.** 반드시 함께 제공된 `email_template.html`(메일)·`report_template.html`(보고서)을 **열어서 그 구조를 기반으로** 채웁니다. `{{ }}` 자리만 분석 결과로 바꾸면 디자인이 자동으로 맞춰집니다.

> 만약 `design-set.md`·`email_template.html`·`report_template.html`이 보이지 않으면, 스킬이 **리소스 없는 단일 파일로 등록**된 것입니다. zip(리소스 포함)으로 다시 업로드하세요.

## 메일
1. **받는 사람 확인** — 안 알려주면 먼저 물어보기. 본인/지정 다수 모두 가능.
2. 제목은 핵심 결론 한 줄.
3. 보내기 전 **받는 사람·제목·내용 미리보기 → 확인받기.** 확인 전 발송 금지.
4. 외부 주소가 섞이면 한 번 더 확인. 보낸 뒤 결과 알려주기.
5. 숫자는 분석 결과만 사용(지어내지 않기).
6. **메일 헤더·표 머리처럼 흰 글씨를 쓰는 곳은 반드시 마젠타 단색 배경(`bgcolor="#C2185B"`)을 깐다.** 그라데이션만 쓰면 Outlook에서 글씨가 안 보입니다(자세히는 `design-set.md`).

## 보고서
1. **HTML로** 만들고 다운로드할 수 있게 저장.
2. 구성: 제목 → 핵심 지표 3개 → 표 → 한 줄 해석.
3. 안내용 Word 문서가 있으면 말투·형식을 따르기.

## 보고서 HTML을 메일에 첨부할 때 (중요 — 검증됨)
HTML 파일을 메일에 **직접 첨부**하면 파일을 Base64로 바꿀다가 **토큰이 터져 실패**합니다.
대신 **OneDrive에 올리고 링크로 첨부**합니다(검증 완료).

```
❌ 쓰지 말 것: 파일 직접 첨부(Base64) → 토큰 리밋
✅ 표준: OneDrive 업로드 → 링크(URL)로 첨부
```

**순서 (OneDrive MCP + Mail)**
1. 생성한 HTML을 OneDrive에 올린다 — `createSmallTextFileInMyOnedrive`(`filename`, `contentText`).
   - 파일 내용을 글자로 그대로 전달하므로 Base64 변환이 없고 토큰을 안 썬다.
2. 응답에서 `id`(fileId)와 `webUrl`을 기억한다.
3. 필요하면 공유 설정 — `shareFileOrFolderInMyOnedrive`(`fileOrFolderId`, `recipientEmails`, `roles=["read"]`).
4. 메일 초안을 만든다 — `CreateDraftMessage`(`to`, `subject`, `body`, `contentType="HTML"`).
5. 초안에 링크를 첨부한다 — `UpdateDraft`(`messageId`, `attachmentUris=[webUrl]`). `hasAttachments: true` 확인.
6. **사용자 확인 후** 발송 — `SendDraftMessage`(`id`).

**파일 크기별 업로드 도구**
- 텍스트 ≤ 5MB: `createSmallTextFileInMyOnedrive` (HTML 보고서는 보통 여기)
- 바이너리 ≤ 5MB: `createSmallBinaryFileInMyOnedrive`
- 5MB 초과: `UploadLargeAttachment` (직접 첨부·Base64 — 토큰 주의)

**메모**
- `attachmentUris`에는 URL만 들어가므로 AI 컨텍스트에 파일 내용이 안 들어온다 → 토큰 안전.
- 세션 시작 시 OneDrive 도구(`createSmallTextFileInMyOnedrive` 등)가 보이는지 확인. 안 보이면 사용자에게 MCP 재연결을 요청.
- (추후 확인) 5MB 초과 HTML·사외 수신자 공유 권한은 미테스트.

## 함께 제공되는 파일
- `design-set.md` — 색상 안내(아이보리/마젠타).
- `email_template.html` — 메일 템플릿.
- `report_template.html` — HTML 보고서 템플릿(막대 차트 포함).

> 템플릿의 `{{ }}` 부분은 에이전트가 분석 결과로 채웁니다. 메이커는 색·구조만 정해주면 됩니다.

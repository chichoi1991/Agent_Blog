# Automation — Action Folder Processing (평일 30분마다 · 초안 생성)

액션 폴더(Reply/Read/Learn)를 열어 매칭 스킬을 실행한다. **초안까지만** 만들고 전송하지 않는다.

## 프롬프트

```
내 Outlook 액션 폴더(Inbox / 🗂️ Assistant)를 확인해줘.
- Reply · Principal / Reply · Assistant 의 메일은 reply-draft 스킬로 폴더에 맞는 어투의 회신
  초안을 만들고 'Scout: Drafted' 태그를 달아줘. 절대 전송하지 마.
- Read 폴더는 inbox-triage 로 한 통의 다이제스트 요약을 만들어줘.
- Learn · Accept / Learn · Decline 은 초대 처리 패턴만 학습하고, 거절 사유는 일반적으로 유지해.
폴더 생성·전송·영구 삭제는 하지 말고, 초안·요약·학습만 해. 새 초안이 몇 개 생겼는지 요약해줘.
```

## 스케줄
- 권장: 평일 30분마다
- 성격: **초안 생성** (초안 품질을 신뢰하게 된 뒤 켜기)

# CONFIG — 채워야 할 값(placeholder) 목록

설치 중 채우는 사람·조직 특정 값입니다. 모르는 값은 비워 두면 해당 기능만 비활성됩니다.
어떤 값도 특정 조직 전용으로 하드코딩하지 않습니다 — 전부 사용자가 채웁니다.

## 정체성 / 어투

| 토큰 | 의미 | 예시 |
|---|---|---|
| `{{PRINCIPAL_FIRST_NAME}}` | 지원 대상(상사) 또는 본인 이름 | Alex |
| `{{PRINCIPAL_FULL_NAME}}` | 상사 전체 이름 | Alex Kim |
| `{{PRINCIPAL_EMAIL}}` | 상사 이메일 | alex@example.com |
| `{{ASSISTANT_NAME}}` | 비서(또는 본인) 표시 이름 | Jordan |
| `{{ASSISTANT_SIGNATURE}}` | 비서 명의 회신 서명 | Jordan · Office of Alex Kim |
| `{{PRINCIPAL_VOICE_NOTES}}` | 상사 어투 특징(간결/따뜻함 등) | 짧고 직접적, 이모지 없음 |

## 조직 / 연락처

| 토큰 | 의미 |
|---|---|
| `{{TIMEZONE}}` | 기본 시간대(예: Asia/Seoul) |
| `{{WORKING_HOURS}}` | 근무 시간(예: 09:00–18:00) |
| `{{PRIORITY_CONTACTS}}` | 우선 처리할 사람 목록(이름·이메일) |
| `{{LEADERSHIP}}` | 리더십/조직 상단 인물(선택) |
| `{{KEY_PROJECTS}}` | 자주 등장하는 프로젝트명 |

## 회의 / 회의실 (선택)

| 토큰 | 의미 |
|---|---|
| `{{PREFERRED_ROOMS}}` | 선호 회의실 이름·정원·특징 |
| `{{ROOM_MAILBOX_FORMAT}}` | 룸 리소스 메일 형식(예: `room-<id>@example.com`) |
| `{{DEFAULT_MEETING_LENGTH}}` | 기본 회의 길이(예: 30분) |
| `{{IN_PERSON_LOCATION}}` | 대면 기본 장소(자유 텍스트) |

## 승인 / 워크플로 (선택)

| 토큰 | 의미 |
|---|---|
| `{{APPROVAL_SENDERS}}` | 승인 알림을 보내는 발신자(있으면) |
| `{{APPROVAL_THRESHOLD}}` | 자동 승인 상한(초과 시 사람 확인) |
| `{{SHUTTLE_OR_TRANSPORT_EMAIL}}` | 차량/교통 예약 창구(있으면) |

> 승인·교통 관련 값은 조직마다 시스템이 다릅니다. **여기엔 어떤 실제 시스템도 미리 넣지 않습니다.**
> 각자 환경의 발신자·창구를 채워 넣으세요. 값이 없으면 해당 스킬은 "확인 요청"으로만 동작합니다.

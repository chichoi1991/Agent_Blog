# CHANGELOG

이 스타터 템플릿의 버전 이력입니다. (특정 조직 배포 패키지가 아닌, 공개 교육용 범용 템플릿)

## v1.0.0 — 2026-07-28

### Added
- 최초 공개. 범용 클린룸 스타터 템플릿 구성:
  - 문서: `README.md`, `SETUP-GUIDE.md`, `CONFIG.md`
  - 스킬 5종: `inbox-triage`, `reply-draft`, `schedule-meeting`, `book-room`, `daily-briefing`
  - 자동화 프롬프트 3종: `daily-meeting-briefing`, `action-folder-processing`, `weekly-focus-time`
- 모든 사람·조직 특정 값은 `{{PLACEHOLDER}}` 토큰으로 분리.
- **초안 우선 / 비공개 기본 / 리스크에서 멈춤 / 조직 중립** 4대 원칙 적용.

### Notes
- 특정 조직의 승인 시스템·건물·룸 메일박스·서비스 계정·제3자 앱을 일절 포함하지 않음.
- 실제 사내 배포 패키지의 개념을 참고했으나, 내부 파일·값은 한 줄도 포함하지 않은 신규 작성물.
